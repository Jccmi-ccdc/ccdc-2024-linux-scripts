run linuxscriptrunner.sh as sudo
may need to run chmod +x on new dls
chmod +x linuxscriptrunner.sh     ###(or other script)
chmod +x *.sh
